import React, { useState } from 'react';
import './App.css';
import Header from './components/Header';
import Home from './components/Home';
import Navbar from './components/Navbar';
import Business from './components/Business';
import { Route, Routes } from "react-router-dom"
import Setting from './components/Setting';
import Loan from './components/Loan';
import User from './components/User';
import Graph from './components/Graph';
import View from './components/View';
import AddNewSetting from './components/AddNewSetting';

function App() {
  const [hambur, setHambur] = useState(true)
  console.log(hambur)
  const hangleHam = () => {
    setHambur(!hambur);
  }
  return (
    <>
      <div className="outer">
        <Navbar hambur={hambur} />
        <div className="main_page">
          <Header hangleHam={hangleHam} />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/business" element={<Business />} />
            <Route path="/Setting" element={<Setting />} />
            <Route path="/Loan" element={<Loan />} />
            <Route path="/User" element={<User />} />
            <Route path="/Graph" element={<Graph />} /> 
            <Route path="/View" element={<View />} /> 
            <Route path="/AddNewSetting" element={<AddNewSetting />} /> 
          </Routes>
        </div>
      </div>
    </>
  );
}

export default App;
