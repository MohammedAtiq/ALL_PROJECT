import React from 'react'
import mainLogo from '../images/mainLogo.svg';
import MyImage from '../images/home-icon1.svg';
import business from '../images/business.svg';
import Group from '../images/Group 1025.svg';
import users from '../images/users.svg';
import settings from '../images/settings-icon.svg';
import { NavLink } from "react-router-dom";


const Navbar = ({ hambur }) => {
    console.log("hambur", hambur)
    return (
        <>
            <div className={hambur ? "main_sidebar" : "main_sidebar show"}>
                <div className="sidebar_fixed">
                    <img
                        src={mainLogo}
                        class="img-fluid mainlogo"
                        alt="..."
                    />
                    <div class="list">
                        <NavLink to="/"> <img src={MyImage} alt="" /> <span> Dashboard</span>  </NavLink>
                        <NavLink to="/business"> <img src={business} alt="" /> <span> Business </span></NavLink>
                        <NavLink to="/Setting"> <img src={settings} alt="" /> <span>Settings </span> </NavLink>
                        <NavLink to="/Loan"> <img src={Group} alt="" /> <span>Loan </span> </NavLink>
                        <NavLink to="/User"> <img src={users} alt="" /> <span> Users</span> </NavLink>
                        <NavLink to="/Graph"> <img src={MyImage} alt="" /> <span> Graph</span> </NavLink>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Navbar
