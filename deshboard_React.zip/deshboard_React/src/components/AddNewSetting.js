import React from 'react'

const AddNewSetting = () => {
    return (
        <div className="container-fluid ">
            <div className="row head">
                <div className="col"><h5>Business Service Partners</h5></div>
                <div className="col-auto"><p>Business / Create Business</p></div>
            </div>
            <div className="card  mt-4">
                <h5 className="card-header">Set Notifications</h5>
                <div className="card-body">
                    <div className="row">
                        <div className="col">
                            <div className="mb-3">
                                <label htmlFor="exampleInputEmail1" className="form-label">Loan Types</label>
                                <select className="form-select" aria-label="Default select example">
                                    <option selected>~Select~</option>
                                    <option value={1}>One</option>
                                    <option value={2}>Two</option>
                                    <option value={3}>Three</option>
                                </select>
                            </div>
                        </div>
                        <div className="col">
                            <div className="mb-3">
                                <label htmlFor="exampleInputEmail1" className="form-label">Sub Category</label>
                                <select className="form-select" aria-label="Default select example">
                                    <option selected>~Select~</option>
                                    <option value={1}>One</option>
                                    <option value={2}>Two</option>
                                    <option value={3}>Three</option>
                                </select>
                            </div>
                        </div>
                        <div className="col">
                            <div className="mb-3">
                                <label htmlFor="exampleInputEmail1" className="form-label">Notification</label>
                                <select className="form-select" aria-label="Default select example">
                                    <option selected>~Select~</option>
                                    <option value={1}>One</option>
                                    <option value={2}>Two</option>
                                    <option value={3}>Three</option>
                                </select>
                            </div>
                        </div>
                        <div className="col">
                            <div className="mb-3">
                                <label htmlFor="exampleInputEmail1" className="form-label">Status</label>
                                <select className="form-select" aria-label="Default select example">
                                    <option selected>~Select~</option>
                                    <option value={1}>One</option>
                                    <option value={2}>Two</option>
                                    <option value={3}>Three</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="card  mt-4">
                <h5 className="card-header">Custom alerts for customers</h5>
                <span><i className="fa fa-plus-circle plusIcon" aria-hidden="true" /></span>
                <div className="card-body">
                    <div className="row">
                        <div className="col">
                            <div className="mb-3">
                                <label htmlFor="exampleInputEmail1" className="form-label">Duration</label>
                                <select className="form-select" aria-label="Default select example">
                                    <option selected>~Select~</option>
                                    <option value={1}>One</option>
                                    <option value={2}>Two</option>
                                    <option value={3}>Three</option>
                                </select>
                            </div>
                        </div>
                        <div className="col">
                            <div className="mb-3">
                                <label htmlFor="exampleInputEmail1" className="form-label">Time in Hours</label>
                                <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                            </div>
                        </div>
                        <div className="col">
                            <div className="mb-3">
                                <label htmlFor="exampleInputEmail1" className="form-label">Template</label>
                                <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                            </div>
                        </div>
                        <div className="col">
                            <div className="mb-3 visually-hidden">
                                <label htmlFor="exampleInputEmail1" className="form-label">Template</label>
                                <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="card mt-4">
                <h5 className="card-header">Escalation Matrix</h5>
                <span><i className="fa fa-plus-circle plusIcon" aria-hidden="true" /></span>
                <div className="card-body">
                    <div className="row">
                        <div className="col">
                            <div className="mb-3">
                                <label htmlFor="exampleInputEmail1" className="form-label">Duration</label>
                                <select className="form-select" aria-label="Default select example">
                                    <option selected>~Select~</option>
                                    <option value={1}>One</option>
                                    <option value={2}>Two</option>
                                    <option value={3}>Three</option>
                                </select>
                            </div>
                        </div>
                        <div className="col">
                            <div className="mb-3">
                                <label htmlFor="exampleInputEmail1" className="form-label">Time in Hours</label>
                                <select className="form-select" aria-label="Default select example">
                                    <option selected>~Select~</option>
                                    <option value={1}>One</option>
                                    <option value={2}>Two</option>
                                    <option value={3}>Three</option>
                                </select>
                            </div>
                        </div>
                        <div className="col">
                            <div className="mb-3">
                                <label htmlFor="exampleInputEmail1" className="form-label">Template</label>
                                <select className="form-select" aria-label="Default select example">
                                    <option selected>~Select~</option>
                                    <option value={1}>One</option>
                                    <option value={2}>Two</option>
                                    <option value={3}>Three</option>
                                </select>
                            </div>
                        </div>
                        <div className="col">
                            <div className="mb-3">
                                <label htmlFor="exampleInputEmail1" className="form-label">Level</label>
                                <select className="form-select" aria-label="Default select example">
                                    <option selected>~Select~</option>
                                    <option value={1}>One</option>
                                    <option value={2}>Two</option>
                                    <option value={3}>Three</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    )
}

export default AddNewSetting
