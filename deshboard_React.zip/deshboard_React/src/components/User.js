import React from 'react'

const User = () => {
    return (
        <div className="container-fluid ">
            <div className="row head">
                <div className="col"><h5>Users</h5></div>
            </div>
            <div className="row mt-4">
                <div className="col">
                    <div className="dropdown">
                        <button className="btn btn-primary useraBtn float-end mx-3 dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Create User
                        </button>
                        <ul className="dropdown-menu">
                            <li> <button type="button" className="btn btn-outline-primary border-0" onclick="location.href='CreatUser.html';">Create User</button></li>
                            <li> <button type="button" className="btn btn-outline-primary border-0" onclick="location.href='userBulkUpload.html';">Bulk Upload</button></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div className="row ">
                <div className="col-6 mx-auto">
                    <div className="input-group mb-3">
                        <span className="input-group-text" id="basic-addon1"><i className="fa fa-search" aria-hidden="true" /></span>
                        <input type="text" className="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" />
                        <button className="btn btn-outline-secondary" type="button"><i className="fa fa-sliders" aria-hidden="true" />Filters</button>
                    </div>
                </div>
            </div>
            <div className="row mt-4">
                <div className="col ">
                    <ul className="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li className="nav-item " role="presentation">
                            <button className="nav-link businessbtn2 active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">All</button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button className="nav-link businessbtn2" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Bulk Uploaded</button>
                        </li>
                    </ul>
                </div>
            </div>
            <div className="tab-content" id="pills-tabContent">
                <div className="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabIndex={0}>
                    <div className="row mt-3 text-center">
                        <div className="col ">
                            <div className="float-end negBtn check">
                                <button type="button" className="btn btn-outline-primary userBtn">
                                    <input className="form-check-input radiobtn" type="checkbox" defaultValue id="flexCheckIndeterminate" /> <span>2 Selected</span>
                                </button>
                                <button type="button" className="btn btn-outline-primary"><i className="fa fa-trash-o" aria-hidden="true" /> <span>Primary</span> </button>
                                <button type="button" className="btn btn-outline-primary ">
                                    <div className="form-check form-switch">
                                        <input className="form-check-input radiobtn2" type="checkbox" role="switch" id="flexSwitchCheckChecked" defaultChecked />
                                        <span className="form-check-label" htmlFor="flexSwitchCheckChecked">Status</span>
                                    </div>
                                </button>
                                <span>Items Per Page</span>
                                <select className="form-select1" aria-label="Default select example">
                                    <option selected>10</option>
                                    <option value={1}>1</option>
                                    <option value={2}>2</option>
                                    <option value={3}>3</option>
                                </select>
                            </div>
                            <div className="table-responsive">
                                <table className="table border">
                                    <thead>
                                        <tr>
                                            <th><input className="form-check-input radiobtn" type="checkbox" defaultValue id="flexCheckDefault" /></th>
                                            <th className="text-start">Name</th>
                                            <th className="text-start">Email</th>
                                            <th>Reporting</th>
                                            <th>Role</th>
                                            <th>Last Session</th>
                                            <th>Date of Creation</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><input className="form-check-input radiobtn" type="checkbox" defaultValue id="flexCheckDefault" /></td>
                                            <td className="text-start">John Doe</td>
                                            <td className="text-start">test@website.com</td>
                                            <td>John Doe</td>
                                            <td>Admin</td>
                                            <td>1 day ago</td>
                                            <td>27-01-2022</td>
                                        </tr>
                                        <tr>
                                            <td><input className="form-check-input radiobtn" type="checkbox" defaultValue id="flexCheckDefault" /></td>
                                            <td className="text-start">John Doe</td>
                                            <td className="text-start">test@website.com</td>
                                            <td>John Doe</td>
                                            <td>Admin</td>
                                            <td>1 day ago</td>
                                            <td>27-01-2022</td>
                                        </tr>
                                        <tr>
                                            <td><input className="form-check-input radiobtn" type="checkbox" defaultValue id="flexCheckDefault" /></td>
                                            <td className="text-start">John Doe</td>
                                            <td className="text-start">test@website.com</td>
                                            <td>John Doe</td>
                                            <td>Admin</td>
                                            <td>1 day ago</td>
                                            <td>27-01-2022</td>
                                        </tr>
                                        <tr>
                                            <td><input className="form-check-input radiobtn" type="checkbox" defaultValue id="flexCheckDefault" /></td>
                                            <td className="text-start">John Doe</td>
                                            <td className="text-start">test@website.com</td>
                                            <td>John Doe</td>
                                            <td>Admin</td>
                                            <td>1 day ago</td>
                                            <td>27-01-2022</td>
                                        </tr>
                                        <tr>
                                            <td><input className="form-check-input radiobtn" type="checkbox" defaultValue id="flexCheckDefault" /></td>
                                            <td className="text-start">John Doe</td>
                                            <td className="text-start">test@website.com</td>
                                            <td>John Doe</td>
                                            <td>Admin</td>
                                            <td>1 day ago</td>
                                            <td>27-01-2022</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col  m-4 ">
                            <nav aria-label="Page navigation example">
                                <ul className="pagination float-end">
                                    <li className="page-item "><a className="page-link next" href="#">First</a></li>
                                    <li className="page-item"><a className="page-link" href="#"><i className="las la-angle-double-left" /></a></li>
                                    <li className="page-item"><a className="page-link active" href="#">1</a></li>
                                    <li className="page-item"><a className="page-link" href="#">2</a></li>
                                    <li className="page-item"><a className="page-link" href="#">3</a></li>
                                    <li className="page-item"><a className="page-link" href="#">4</a></li>
                                    <li className="page-item"><a className="page-link" href="#">5</a></li>
                                    <li className="page-item"><a className="page-link" href="#">6</a></li>
                                    <li className="page-item"><a className="page-link" href="#"><i className="las la-angle-double-right" /></a></li>
                                    <li className="page-item"><a className="page-link next" href="#">Last</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                <div className="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabIndex={0}>
                    <div className="col mx-3">
                        <div className="float-end negBtn check">
                            <span>Items Per Page</span>
                            <select className="form-select1" aria-label="Default select example">
                                <option selected>10</option>
                                <option value={1}>1</option>
                                <option value={2}>2</option>
                                <option value={3}>3</option>
                            </select>
                        </div>
                        <div className="table-responsive">
                            <table className="table border">
                                <thead>
                                    <tr>
                                        <th>Uploaded By</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Location</th>
                                        <th>Total Records</th>
                                        <th>Success</th>
                                        <th>Failed</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>John Doe</td>
                                        <td>27-01-2022</td>
                                        <td>11:00 PM</td>
                                        <td>Udaipur</td>
                                        <td> <span>2100</span> </td>
                                        <td> <span>2100</span> </td>
                                        <td> <span>0</span> </td>
                                    </tr>
                                    <tr>
                                        <td>John Doe</td>
                                        <td>27-01-2022</td>
                                        <td>11:00 PM</td>
                                        <td>Udaipur</td>
                                        <td> <span>2100</span> </td>
                                        <td> <span>2100</span> </td>
                                        <td> <span>0</span> </td>
                                    </tr>
                                    <tr>
                                        <td>John Doe</td>
                                        <td>27-01-2022</td>
                                        <td>11:00 PM</td>
                                        <td>Udaipur</td>
                                        <td> <span>2100</span> </td>
                                        <td> <span>2100</span> </td>
                                        <td> <span>0</span> </td>
                                    </tr>
                                    <tr>
                                        <td>John Doe</td>
                                        <td>27-01-2022</td>
                                        <td>11:00 PM</td>
                                        <td>Udaipur</td>
                                        <td> <span>2100</span> </td>
                                        <td> <span>2100</span> </td>
                                        <td> <span>0</span> </td>
                                    </tr>
                                    <tr>
                                        <td>John Doe</td>
                                        <td>27-01-2022</td>
                                        <td>11:00 PM</td>
                                        <td>Udaipur</td>
                                        <td> <span>2100</span> </td>
                                        <td> <span>2100</span> </td>
                                        <td> <span>0</span> </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col  mx-5 ">
                            <nav aria-label="Page navigation example">
                                <ul className="pagination float-end">
                                    <li className="page-item "><a className="page-link next" href="#">First</a></li>
                                    <li className="page-item"><a className="page-link" href="#"><i className="las la-angle-double-left" /></a></li>
                                    <li className="page-item"><a className="page-link active" href="#">1</a></li>
                                    <li className="page-item"><a className="page-link" href="#">2</a></li>
                                    <li className="page-item"><a className="page-link" href="#">3</a></li>
                                    <li className="page-item"><a className="page-link" href="#">4</a></li>
                                    <li className="page-item"><a className="page-link" href="#">5</a></li>
                                    <li className="page-item"><a className="page-link" href="#">6</a></li>
                                    <li className="page-item"><a className="page-link" href="#"><i className="las la-angle-double-right" /></a></li>
                                    <li className="page-item"><a className="page-link next" href="#">Last</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    )
}

export default User
