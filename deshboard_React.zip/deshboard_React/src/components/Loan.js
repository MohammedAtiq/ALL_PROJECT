import React from 'react'
import { NavLink } from "react-router-dom";

const Loan = () => {
    return (
        <div className="container-fluid ">
            <div className="row head">
                <div className="col"><h5>Loan Listing</h5></div>
            </div>
            <div className="row">
                <div className="col">
                    <button type="button" className="btn btn-primary  float-end mx-3" onclick="location.href='LoanDataUpload.html';">Upload</button>
                </div>
            </div>
            <div className="row card-body mt-3">
                <div className="col">
                    <div className="mb-3">
                        <label htmlFor="exampleInputEmail1" className="form-label">Loan Type</label>
                        <select className="form-select" aria-label="Default select example">
                            <option selected>~Select~</option>
                            <option value={1}>One</option>
                            <option value={2}>Two</option>
                            <option value={3}>Three</option>
                        </select>
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3">
                        <label htmlFor="exampleInputEmail1" className="form-label">Sub Loan Type</label>
                        <select className="form-select" aria-label="Default select example">
                            <option selected>~Select~</option>
                            <option value={1}>One</option>
                            <option value={2}>Two</option>
                            <option value={3}>Three</option>
                        </select>
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3">
                        <label htmlFor="exampleInputEmail1" className="form-label">Loan Status</label>
                        <select className="form-select" aria-label="Default select example">
                            <option selected>~Select~</option>
                            <option value={1}>One</option>
                            <option value={2}>Two</option>
                            <option value={3}>Three</option>
                        </select>
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3">
                        <label htmlFor="exampleInputEmail1" className="form-label">Payment Status</label>
                        <select className="form-select" aria-label="Default select example">
                            <option selected>~Select~</option>
                            <option value={1}>One</option>
                            <option value={2}>Two</option>
                            <option value={3}>Three</option>
                        </select>
                    </div>
                </div>
            </div>
            <div className="row  card-body">
                <div className="col-3">
                    <div className="mb-3">
                        <label htmlFor="exampleInputEmail1" className="form-label">Loan Account Number</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                </div>
                <div className="col-3">
                    <div className="mb-3">
                        <label htmlFor="exampleInputEmail1" className="form-label">Phone Number</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                </div>
                <div className="col d-flex justify-content-end ">
                    <button type="button" className="btn btn-primary mx-2 my-auto">Filter</button>
                    <button type="button" className="btn btn-outline-primary btnMarg mx-2 my-auto">Clear</button>
                </div>
            </div>
            <div className="row mt-3">
                <div className="col">
                    <div className="table-responsive">
                        <table className="table border">
                            <thead>
                                <tr>
                                    <th className="text-center">#</th>
                                    <th>Loan Account No.</th>
                                    <th>Loan Type</th>
                                    <th className="text-center">Loan Status</th>
                                    <th className="text-center">Last Payment Status</th>
                                    <th>Name</th>
                                    <th>Phone No.</th>
                                    <th className="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td className="text-center">1</td>
                                    <td>1111000001</td>
                                    <td>Personal Loan</td>
                                    <td className="text-center">Open</td>
                                    <td className="text-center">Paid</td>
                                    <td>John Doe</td>
                                    <td><span>12345667890</span></td>
                                    <td className="text-center">
                                        <button type="button" className="btn btn-outline-primary loanbtn " onclick="location.href='ViewData.html';"><NavLink to="/View">View</NavLink> </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td className="text-center">2</td>
                                    <td>1111000001</td>
                                    <td>Personal Loan</td>
                                    <td className="text-center">Open</td>
                                    <td className="text-center">Paid</td>
                                    <td>John Doe</td>
                                    <td><span>12345667890</span></td>
                                    <td className="text-center">
                                        <button type="button" className="btn btn-outline-primary loanbtn " onclick="location.href='ViewData.html';"><NavLink to="/View">View</NavLink> </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td className="text-center">3</td>
                                    <td>1111000001</td>
                                    <td>Personal Loan</td>
                                    <td className="text-center">Open</td>
                                    <td className="text-center">Paid</td>
                                    <td>John Doe</td>
                                    <td><span>12345667890</span></td>
                                    <td className="text-center">
                                        <button type="button" className="btn btn-outline-primary loanbtn " onclick="location.href='ViewData.html';"><NavLink to="/View">View</NavLink></button>
                                    </td>
                                </tr>
                                <tr>
                                    <td className="text-center">4</td>
                                </tr>
                                <tr>
                                    <td className="text-center">5</td>
                                </tr>
                                <tr>
                                    <td className="text-center">6</td>
                                </tr>
                                <tr>
                                    <td className="text-center">7</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div className="row">
                <div className="col  mx-5 ">
                    <nav aria-label="Page navigation example">
                        <ul className="pagination float-end">
                            <li className="page-item"><a className="page-link next" href="#">First</a></li>
                            <li className="page-item"><a className="page-link" href="#"><i className="las la-angle-double-left" /></a></li>
                            <li className="page-item"><a className="page-link active" href="#">1</a></li>
                            <li className="page-item"><a className="page-link" href="#">2</a></li>
                            <li className="page-item"><a className="page-link" href="#">3</a></li>
                            <li className="page-item"><a className="page-link" href="#">4</a></li>
                            <li className="page-item"><a className="page-link" href="#">5</a></li>
                            <li className="page-item"><a className="page-link" href="#">6</a></li>
                            <li className="page-item"><a className="page-link" href="#"><i className="las la-angle-double-right" /></a></li>
                            <li className="page-item"><a className="page-link next" href="#">Last</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>

    )
}

export default Loan
