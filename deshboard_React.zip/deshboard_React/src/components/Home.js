import React from 'react'
import graph1 from '../images/graph1.svg';
import circle from '../images/circle.svg';
import { Bar } from 'react-chartjs-2';
import { CategoryScale } from 'chart.js';
import Chart from 'chart.js/auto';


const Home = () => {
    const data = {
        labels: ['as', 'sd', 'sd', 'sd', 'sd', 'sd', 'sd', 'sd'],
        datasets: [
            {
                label: 'SMS',
                data: [400, 100, 500, 20, 250, 300, 350, 100],
                backgroundColor: 'rgb(51 169 255)'
            },
            {
                label: 'SMS',
                data: [100, 20, 300, 150, 250, 100, 350],
                backgroundColor: 'rgb(164 146 236)'
            }
        ]
    }

    const options = {
        title: {
            display: true,
            text: "Chart Title"
        },
        responsive: true,
        plugins: {
            tooltip: {
                backgroundColor: 'red',
                yAlign: 'bottom',
                usePointStyle: 'boolean',
                events: ['click'],
                display: 'block'
            },
            legend: {
                position: 'bottom',
            },
            interaction: {
                mode: 'point'
            }
        }
    };

    return (
        <div className="container-fluid ">
            <div className="row head">
                <div className="col"><h5>Dashboard</h5></div>
                <div className="col-auto"><p>Dashboard</p></div>
            </div>
            <div className="row ">
                <div className="col-md-6 col-lg-auto">
                    <div className="input-group mb-3 box1">
                        <span className="input-group-text">Date Range</span>
                        <input type="text" className="form-control daterange" />
                    </div>
                </div>
                <div className="col box2  ">
                    <ul className="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li className="nav-item" role="presentation">
                            <button className="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Today</button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button className="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Week</button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button className="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Month</button>
                        </li>
                        <li className="nav-item " role="presentation">
                            <button className="nav-link" id="pills-about-tab" data-bs-toggle="pill" data-bs-target="#pills-about" type="button" role="tab" aria-controls="pills-about" aria-selected="false">Quarter</button>
                        </li>
                    </ul>
                </div>
                <div className="col-auto" />
            </div>
            {/* _______________________________________________________________change */}
            <div className="tab-content" id="pills-tabContent">
                <div className="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabIndex={0}>
                    <div className="row gx-4 gy-2 boxs4 text-center ">
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className=" b1 bg-light"><h5>25</h5><p>Total Case Assigned</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className="  b2 bg-light"><h5>22</h5><p>Solved Case</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className="  b3 bg-light"><h5>1</h5><p>Default Case</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className="  b4 bg-light"><h5>5</h5><p>Pending Case</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className="  b5 bg-light"><h5>22</h5><p>Case Clearance Rate</p></div>
                        </div>
                    </div>
                    <div className="row mt-3">
                        <div className="col-lg-6 ">
                            {/* <div className="imgCenter1">
                                <img src={graph1} className="img-fluid " alt="..." />
                                </div> */}
                            <Bar data={data} options={options} />
                        </div>
                        <div className="col-lg-6 "><div className="imgCenter2"><img src={circle} className="img-fluid" alt=".." /></div></div>
                    </div>
                    <div className="row mt-5 text-center">
                        <div className="col">
                            <table className="table border">
                                <thead>
                                    <tr>
                                        <th>Loan Type</th>
                                        <th>EMI Missed</th>
                                        <th>Amount</th>
                                        <th>Recovered Amount</th>
                                        <th>Pending Amount</th>
                                        <th>Recovery Rate</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Home Loan</td>
                                        <td>30</td>
                                        <td>75000</td>
                                        <td>73500</td>
                                        <td>1500</td>
                                        <td>98%</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div className="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabIndex={0}>
                    <div className="row gx-4 gy-2 boxs4 text-center ">
                        <div className="col ">
                            <div className=" b1 bg-light"><h5>250</h5><p>Total Case Assigned</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className=" b2 bg-light"><h5>2200</h5><p>Solved Case</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className=" b3 bg-light"><h5>100</h5><p>Default Case</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className=" b4 bg-light"><h5>50</h5><p>Pending Case</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className=" b5 bg-light"><h5>2200</h5><p>Case Clearance Rate</p></div>
                        </div>
                    </div>
                    <div className="row mt-3">
                        <div className="col-lg-6 "><div className="imgCenter1"><img src={graph1} className="img-fluid " alt="..." /></div></div>
                        <div className="col-lg-6 "><div className="imgCenter2"><img src={circle} className="img-fluid" alt=".." /></div></div>
                    </div>
                    <div className="row mt-5 text-center">
                        <div className="col">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th>Loan Type</th>
                                        <th>EMI Missed</th>
                                        <th>Amount</th>
                                        <th>Recovered Amount</th>
                                        <th>Pending Amount</th>
                                        <th>Recovery Rate</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Home Loan</td>
                                        <td>30</td>
                                        <td>75000</td>
                                        <td>73500</td>
                                        <td>1500</td>
                                        <td>98%</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div className="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabIndex={0}>
                    <div className="row gx-4 gy-2 boxs4 text-center ">
                        <div className="col ">
                            <div className=" b1 bg-light"><h5>25000</h5><p>Total Case Assigned</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className=" b2 bg-light"><h5>2200</h5><p>Solved Case</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className=" b3 bg-light"><h5>1000</h5><p>Default Case</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className=" b4 bg-light"><h5>5000</h5><p>Pending Case</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className=" b5 bg-light"><h5>22000</h5><p>Case Clearance Rate</p></div>
                        </div>
                    </div>
                    <div className="row mt-3">
                        <div className="col-lg-6 "><div className="imgCenter1"><img src={graph1} className="img-fluid " alt="..." /></div></div>
                        <div className="col-lg-6 "><div className="imgCenter2"><img src={circle} className="img-fluid" alt=".." /></div></div>
                    </div>
                    <div className="row mt-5 text-center">
                        <div className="col">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th>Loan Type</th>
                                        <th>EMI Missed</th>
                                        <th>Amount</th>
                                        <th>Recovered Amount</th>
                                        <th>Pending Amount</th>
                                        <th>Recovery Rate</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Home Loan</td>
                                        <td>30</td>
                                        <td>75000</td>
                                        <td>73500</td>
                                        <td>1500</td>
                                        <td>98%</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div className="tab-pane fade" id="pills-about" role="tabpanel" aria-labelledby="pills-about-tab" tabIndex={0}>
                    <div className="row gx-4 gy-2 boxs4 text-center ">
                        <div className="col ">
                            <div className=" b1 bg-light"><h5>25000</h5><p>Total Case Assigned</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className=" b2 bg-light"><h5>2200</h5><p>Solved Case</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className=" b3 bg-light"><h5>1000</h5><p>Default Case</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className=" b4 bg-light"><h5>5000</h5><p>Pending Case</p></div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg ">
                            <div className=" b5 bg-light"><h5>22000</h5><p>Case Clearance Rate</p></div>
                        </div>
                    </div>
                    <div className="row mt-3">
                        <div className="col-lg-6 "><div className="imgCenter1"><img src={graph1} className="img-fluid " alt="..." /></div></div>
                        <div className="col-lg-6 "><div className="imgCenter2"><img src={circle} className="img-fluid" alt=".." /></div></div>
                    </div>
                    <div className="row mt-5 text-center">
                        <div className="col">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th>Loan Type</th>
                                        <th>EMI Missed</th>
                                        <th>Amount</th>
                                        <th>Recovered Amount</th>
                                        <th>Pending Amount</th>
                                        <th>Recovery Rate</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Home Loan</td>
                                        <td>30</td>
                                        <td>75000</td>
                                        <td>73500</td>
                                        <td>1500</td>
                                        <td>98%</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    )
}

export default Home
