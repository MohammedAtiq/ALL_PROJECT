import React from 'react'

const View = () => {
    return (
        <div className="container-fluid ">
            <div className="row head">
                <div className="col"><h5>Loan Listing</h5></div>
            </div>
            <div className="row  mt-4">
                <div className="col">
                    <div className="mb-3 position-relative">
                        <label htmlFor="exampleInputEmail1" className="form-label">Loan Account No.</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3 position-relative">
                        <label htmlFor="exampleInputEmail1" className="form-label">Customer Name</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3 position-relative">
                        <label htmlFor="exampleInputEmail1" className="form-label">Loan Type</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3 position-relative">
                        <label htmlFor="exampleInputEmail1" className="form-label">Loan Sub Type</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                </div>
            </div>
            <div className="row  mt-3">
                <div className="col">
                    <div className="mb-3 position-relative">
                        <label htmlFor="exampleInputEmail1" className="form-label">Arrears</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3 position-relative">
                        <label htmlFor="exampleInputEmail1" className="form-label">Total Amount of Loan</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3 position-relative">
                        <label htmlFor="exampleInputEmail1" className="form-label">Paid Amount</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3 position-relative">
                        <label htmlFor="exampleInputEmail1" className="form-label">Remaining Amount</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                </div>
            </div>
            <div className="row mt-3">
                <div className="col">
                    <div className="mb-3 position-relative ">
                        <label htmlFor="exampleInputEmail1" className="form-label">Loan Start Date</label>
                        <input type="date" className="form-control datepicker" />
                        <span className="calPosit"><i className="fa fa-calendar-o" aria-hidden="true" /></span>
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3 position-relative">
                        <label htmlFor="exampleInputEmail1" className="form-label">Loan End Date</label>
                        <input type="date" className="form-control datepicker" id="exampleInputEmail1" aria-describedby="emailHelp" />
                        <span className="calPosit"><i className="fa fa-calendar-o" aria-hidden="true" /></span>
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3 position-relative">
                        <label htmlFor="exampleInputEmail1" className="form-label">Payment Data</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3 position-relative">
                        <label htmlFor="exampleInputEmail1" className="form-label">Last Payment Status</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                </div>
            </div>
            <div className="row mt-3">
                <div className="col-3">
                    <div className="mb-3 position-relative">
                        <label htmlFor="exampleInputEmail1" className="form-label">Phone No.</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                </div>
                <div className="col-3">
                    <div className="mb-3 position-relative">
                        <label htmlFor="exampleInputEmail1" className="form-label">Alternative No.</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3 position-relative">
                        <label htmlFor="exampleInputEmail1" className="form-label">Remarks</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    </div>
                </div>
            </div>
            <button type="button" className="btn btn-outline-primary btnMarg" onclick="location.href='PaymentHistory.html';">View Payment History</button>
            <div className="col text-center mt-5">
                <button type="button" className="btn btn-secondary inpBtn1">Reset</button>
                <button type="button" className="btn btn-primary inpBtn1">Create</button>
            </div>
        </div>

    )
}

export default View
