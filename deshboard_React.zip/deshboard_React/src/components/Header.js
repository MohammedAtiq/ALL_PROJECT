import React from 'react'
import hemburger from '../images/hemburger.svg';
import bell from '../images/bell.svg';
import usersideicon from '../images/usersideicon.svg';

const Header = ({ hangleHam }) => {
    return (
        <nav className="navbarMain">
            <span className="icontoggle ms-3">
                <img src={hemburger} onClick={hangleHam} alt="" />
            </span>
            <div className="detail mx-4 d-flex ">
                <div className="me-2"> <img src={bell} alt="" /> </div>
                <div className="dropdown">
                    <button className="btn dropdown-toggle  logInIcon" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src={usersideicon} alt="" />
                    </button>
                    <ul className="dropdown-menu dropdown-menu-end">
                        <button onclick="location.href='login.html'" style={{ cursor: 'pointer', border: 'none' }}><i className="fa fa-user mx-2" aria-hidden="true" /> Profile</button>
                        <button onclick="location.href='login.html'" style={{ cursor: 'pointer', border: 'none' }}> <i className="fa fa-sign-out mx-2" aria-hidden="true"> </i>Login</button>
                    </ul>
                </div>
            </div>
        </nav>
    )
}

export default Header
