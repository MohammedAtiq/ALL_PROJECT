import React from 'react'
import { NavLink } from "react-router-dom";

const Setting = () => {
    return (
        <div className="container-fluid ">
            <div className="row head">
                <div className="col"><h5>Settings</h5></div>
            </div>
            <div className="row mt-3">
                <div className="col">
                    <ul className="nav nav-pills" id="pills-tab" role="tablist">
                        <li className="nav-item " role="presentation">
                            <button className="nav-link businessbtn2 active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Configuration</button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button className="nav-link businessbtn2" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Template</button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button className="nav-link businessbtn2" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Collection Matrix Status</button>
                        </li>
                    </ul>
                </div>
            </div>
            <div className="tab-content" id="pills-tabContent">
                <div className="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabIndex={0}>
                    <div className="row mt-3 text-center">
                        <div className="col ">
                            <button type="button" className="btn-primary businessbtn1 float-end " onclick="location.href='Configuration.html';"><NavLink to="/AddNewSetting"> Add New</NavLink></button>
                            <div className="table-responsive">
                                <table className="table border">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th className="text-start">Loan Types</th>
                                            <th className="text-start">Subcategory / Scheme</th>
                                            <th className="text-start">Notification</th>
                                            <th>Created Date</th>
                                            <th>Created By</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td className="text-start">Personal Loan</td>
                                            <td className="text-start">Insta Loan</td>
                                            <td className="text-start">SMS</td>
                                            <td>01-01-2022</td>
                                            <td>John Doe</td>
                                            <td>
                                                <button className="editBtn"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>2</td>
                                            <td className="text-start">Personal Loan</td>
                                            <td className="text-start">Insta Loan</td>
                                            <td className="text-start">SMS</td>
                                            <td>01-01-2022</td>
                                            <td>John Doe</td>
                                            <td>
                                                <button className="editBtn"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td className="text-start">Personal Loan</td>
                                            <td className="text-start">Insta Loan</td>
                                            <td className="text-start">SMS</td>
                                            <td>01-01-2022</td>
                                            <td>John Doe</td>
                                            <td>
                                                <button className="editBtn"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>4</td>
                                        </tr>
                                        <tr>
                                            <td>5</td>
                                        </tr>
                                        <tr>
                                            <td>6</td>
                                        </tr>
                                        <tr>
                                            <td>7</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col  mx-5 ">
                            <nav aria-label="Page navigation example">
                                <ul className="pagination float-end">
                                    <li className="page-item "><a className="page-link next" href="/">First</a></li>
                                    <li className="page-item"><a className="page-link" href="/"><i className="las la-angle-double-left" /></a></li>
                                    <li className="page-item"><a className="page-link active" href="/">1</a></li>
                                    <li className="page-item"><a className="page-link" href="/">2</a></li>
                                    <li className="page-item"><a className="page-link" href="/">3</a></li>
                                    <li className="page-item"><a className="page-link" href="/">4</a></li>
                                    <li className="page-item"><a className="page-link" href="/">5</a></li>
                                    <li className="page-item"><a className="page-link" href="/">6</a></li>
                                    <li className="page-item"><a className="page-link" href="/"><i className="las la-angle-double-right" /></a></li>
                                    <li className="page-item"><a className="page-link next" href="/">Last</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                <div className="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabIndex={0}>
                    <div className="ms-3 mt-2 settingPera"><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting.</p></div>
                    <div className="card">
                        <div className="card-header">
                            <h5>Notifications (Email &amp; In App)</h5>
                        </div>
                        <ul className="list-group ">
                            <li className="list-group-item item1 m-2"><h4>Template-1</h4>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500.</p></li>
                            <li className="list-group-item item2 m-2"><h4>Template-2</h4>
                                <p>Fusce maximus turpis quis nulla volutpat iaculis Fusce maximus turpis quis nulla volutpat iaculis Fusce maximus turpis quis nulla volutpat iaculis Fusce maximu.</p></li>
                            <li className="list-group-item item3 m-2"><h4>Template-3</h4>
                                <p>Fusce maximus turpis quis nulla volutpat iaculis Fusce maximus turpis quis nulla volutpat iaculis Fusce maximus turpis quis nulla volutpat iaculis Fusce maximu.</p></li>
                            <li className="list-group-item item4 m-2"><h4>Template-4</h4>
                                <p>Fusce maximus turpis quis nulla volutpat iaculis Fusce maximus turpis quis nulla volutpat iaculis Fusce maximus turpis quis nulla volutpat iaculis Fusce maximu.</p></li>
                            <li className="list-group-item item5 m-2"><h4>Template-5</h4>
                                <p>Fusce maximus turpis quis nulla volutpat iaculis Fusce maximus turpis quis nulla volutpat iaculis Fusce maximus turpis quis nulla volutpat iaculis Fusce maximu.</p></li>
                            <li className="list-group-item item6 m-2"><h4>Template-6</h4>
                                <p>Fusce maximus turpis quis nulla volutpat iaculis Fusce maximus turpis quis nulla volutpat iaculis Fusce maximus turpis quis nulla volutpat iaculis Fusce maximu.</p></li>
                        </ul>
                    </div>
                </div>
                <div className="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabIndex={0}>
                    <div className="drag_wrapper">
                        <div className="dragArea">
                            <div className="dragbtn_wrapper">
                                <i className="fa fa-cloud-upload" aria-hidden="true" />
                                <h4>Drag CSV to Upload</h4>
                                <p className="text-muted">OR</p>
                                <button className="upload_btn">
                                    <span>Choose File</span>
                                    <input type="file" />
                                </button>
                                <p className="text-muted">Upto 5 MB</p>
                            </div>
                        </div>
                    </div>
                    <div className="table-responsive">
                        <table className="table border text-center">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Uploaded By</th>
                                    <th>Records</th>
                                    <th>Status</th>
                                    <th>Success Count</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>27-01-2022</td>
                                    <td>Vijay Kumar</td>
                                    <td>100</td>
                                    <td>Completed</td>
                                    <td>100</td>
                                </tr>
                                <tr>
                                    <td>27-01-2022</td>
                                    <td>Vijay Kumar</td>
                                    <td>100</td>
                                    <td>Completed</td>
                                    <td>100</td>
                                </tr>
                                <tr>
                                    <td>27-01-2022</td>
                                    <td>Vijay Kumar</td>
                                    <td>100</td>
                                    <td>Completed</td>
                                    <td>100</td>
                                </tr>
                                <tr>
                                    <td>27-01-2022</td>
                                    <td>Vijay Kumar</td>
                                    <td>100</td>
                                    <td>Completed</td>
                                    <td>100</td>
                                </tr>
                                <tr>
                                    <td>27-01-2022</td>
                                    <td>Vijay Kumar</td>
                                    <td>100</td>
                                    <td>Completed</td>
                                    <td>100</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Setting
