import React from 'react'

const Business = () => {
    return (
        <div className="container-fluid ">
            <div className="row head">
                <div className="col"><h5>Business Service Partners</h5></div>
                <div className="col-auto"><p>Business</p></div>
            </div>
            <div className="row">
                <div className="col">
                    <button type="button" className="btn-primary  float-end " onclick="location.href='CreateBusiness.html';">Create Business</button>
                </div>
            </div>
            <div className="row mt-3">
                <div className="col">
                    <div className="table-responsive">
                        <table className="table border">
                            <thead>
                                <tr>
                                    <th className="text-center">#</th>
                                    <th>Business Name</th>
                                    <th>Mobile</th>
                                    <th>Email</th>
                                    <th className="text-center">Users</th>
                                    <th className="text-center">Created Date</th>
                                    <th className="text-center">View</th>
                                    <th className="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td className="text-center">1</td>
                                    <td>John Doe</td>
                                    <td>12345667890</td>
                                    <td>test@email.com</td>
                                    <td className="text-center">01</td>
                                    <td className="text-center">01-01-2022</td>
                                    <td className="text-center"> <a href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#exampleModal">View Licenses</a></td>
                                    <td className="text-center">
                                        <button className="editBtn"><i className="las la-edit " /></button>
                                        <div className="form-check form-switch switBtn">
                                            <input className="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td className="text-center">2</td>
                                    <td>John Doe</td>
                                    <td>12345667890</td>
                                    <td>test@email.com</td>
                                    <td className="text-center">05</td>
                                    <td className="text-center">01-01-2022</td>
                                    <td className="text-center"> <a href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#exampleModal">View Licenses</a></td>
                                    <td className="text-center">
                                        <button className="editBtn"><i className="las la-edit " /></button>
                                        <div className="form-check form-switch switBtn">
                                            <input className="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td className="text-center">3</td>
                                    <td>John Doe</td>
                                    <td>12345667890</td>
                                    <td>test@email.com</td>
                                    <td className="text-center">08</td>
                                    <td className="text-center">01-01-2022</td>
                                    <td className="text-center"> <a href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#exampleModal">View Licenses</a></td>
                                    <td className="text-center">
                                        <button className="editBtn"><i className="las la-edit " /></button>
                                        <div className="form-check form-switch switBtn">
                                            <input className="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td className="text-center">4</td>
                                </tr>
                                <tr>
                                    <td className="text-center">5</td>
                                </tr>
                                <tr>
                                    <td className="text-center">6</td>
                                </tr>
                                <tr>
                                    <td className="text-center">7</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div className="modal fade " id="exampleModal" tabIndex={-1} aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div className="modal-dialog modal-lg modal-dialog-centered">
                    <div className="modal-content ">
                        <div className="modal-header">
                            <h1 className="modal-title fs-5" id="exampleModalLabel" style={{ fontWeight: 700 }}>Business Name Here</h1>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" />
                        </div>
                        <div className="modal-body">
                            <div className="table-responsive">
                                <table className="table table-bordered modalTable">
                                    <thead>
                                        <tr>
                                            <th>S.No.</th>
                                            <th className="text-start">Product Access</th>
                                            <th>No. of License</th>
                                            <th>Start Date</th>
                                            <th>Expiry Date</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td className="text-start">DMS</td>
                                            <td>3</td>
                                            <td>01-01-2022</td>
                                            <td>01-01-2022</td>
                                            <td className="text-center">
                                                <button className="editBtn"><i className="las la-edit " /></button>
                                                <div className="form-check form-switch switBtn">
                                                    <input className="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td className="text-start">DMS</td>
                                            <td>3</td>
                                            <td>01-01-2022</td>
                                            <td>01-01-2022</td>
                                            <td className="text-center">
                                                <button className="editBtn"><i className="las la-edit " /></button>
                                                <div className="form-check form-switch switBtn">
                                                    <input className="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td className="text-start">DMS</td>
                                            <td>3</td>
                                            <td>01-01-2022</td>
                                            <td>01-01-2022</td>
                                            <td className="text-center">
                                                <button className="editBtn"><i className="las la-edit " /></button>
                                                <div className="form-check form-switch switBtn">
                                                    <input className="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="row">
                <div className="col  mx-5 ">
                    <nav aria-label="Page navigation example">
                        <ul className="pagination float-end">
                            <li className="page-item "><a className="page-link next" href="/">First</a></li>
                            <li className="page-item"><a className="page-link" href="/"><i class="fa fa-arrow-left" aria-hidden="true"></i></a></li>
                            <li className="page-item"><a className="page-link active" href="/">1</a></li>
                            <li className="page-item"><a className="page-link" href="/">2</a></li>
                            <li className="page-item"><a className="page-link" href="/">3</a></li>
                            <li className="page-item"><a className="page-link" href="/">4</a></li>
                            <li className="page-item"><a className="page-link" href="/">5</a></li>
                            <li className="page-item"><a className="page-link" href="/">6</a></li>
                            <li className="page-item"><a className="page-link" href="/"><i class="fa fa-arrow-right" aria-hidden="true"></i></a></li>
                            <li className="page-item"><a className="page-link next" href="/">Last</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>

    )
}

export default Business
