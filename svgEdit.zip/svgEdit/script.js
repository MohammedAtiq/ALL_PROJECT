

let content = document.querySelector('.cls-12')

function text() {
    var x = document.getElementById('option');
    var value = x.value;
    console.log(value)

    if (value === "bold") {
        content.style.fontWeight = 'bold'
        content.style.fontStyle = 'none'
        content.style.textDecoration = 'none'
    } else if (value === "italic") {
        content.style.fontStyle = 'italic'
        content.style.fontWeight = 'none'
        content.style.textDecoration = 'none'
    } else if (value === "underline") {
        content.style.textDecoration = 'underline'
        content.style.fontWeight = 'none'
        content.style.fontStyle = 'none'
    } else if (value === "") {
        content.style.textDecoration = 'none'
        content.style.fontWeight = 'none'
        content.style.fontStyle = 'none'
    }
}


let btnBold = document.querySelector('#cursive')
let btnUnder = document.querySelector('#fantasy')
let btnItalic = document.querySelector('#monospace')

btnBold.addEventListener('click', () => content.style.fontFamily = 'cursive');
btnUnder.addEventListener('click', () => content.style.fontFamily = 'fantasy');
btnItalic.addEventListener('click', () => content.style.fontFamily = 'monospace');


let increase = document.querySelector('#increase')
let decrease = document.querySelector('#decrease')
let textSize = 108.27

increase.addEventListener('click', () => { textSize = textSize + 5; content.style.fontSize = textSize + 'px' });

decrease.addEventListener('click', () => { textSize = textSize - 5; content.style.fontSize = textSize + 'px' });
