import React from 'react'
import ShopNav from './ShopNav'

const Inbox = () => {
  return (
    <div>
        <ShopNav/>
     <h1>inbox</h1>
    </div>
  )
}

export default Inbox
