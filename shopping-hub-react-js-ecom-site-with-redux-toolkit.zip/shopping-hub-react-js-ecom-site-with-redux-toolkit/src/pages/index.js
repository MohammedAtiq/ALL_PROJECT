import Home from "./HomePage/HomePage";
import Category from "./CategoryPage/CategoryPage";
import Cart from "./CartPage/CartPage";

export {Home, Category, Cart};